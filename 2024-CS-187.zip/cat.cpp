#include<iostream>
using namespace std;
main()
{
 cout<< "';-.          ---'           " <<endl;
 cout<< "  '.'!-....-/'.-''           " <<endl;
 cout<< "    !        /      ,        " <<endl;
 cout<< "    /()   () !    .' '-._    " <<endl;
 cout<< "   |)  .    ()!  /   -.'     " <<endl;
 cout<< "    |  -'-     ,; '. <       " <<endl;
 cout<< "    ;.--     ,;|   > |       " <<endl;
 cout<< "   / ,    / ,  |.-'.-'       " <<endl;
 cout<< "  (_/    (_/ ,;|.<'          " <<endl;
 cout<< "    !    ,     ;-'           " <<endl;
 cout<< "     >   !    /              " <<endl;
 cout<< "    (_,-''> .'               " <<endl;
 cout<< "      (_,'                   " <<endl;
}