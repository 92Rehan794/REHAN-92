#include<iostream>
using namespace std;
main()
{
 cout<< "+--^----------,--------,-----,--------^-,   " <<endl;
 cout<< " | |||||||||   '--------'     |          O  " <<endl;
 cout<< " '+---------------------------^----------|  " <<endl;
 cout<< "   ',---------,---------,--------------'    " <<endl;
 cout<< "     / XXXXXX /'|       /'                  " <<endl;
 cout<< "    / XXXXXX /  |      /'                   " <<endl;
 cout<< "   / XXXXXX /'-------'                      " <<endl;
 cout<< "  / XXXXXX /                                " <<endl;
 cout<< " / XXXXXX /                                 " <<endl;
 cout<< "(--------(                                  " <<endl;
 cout<< " '------'                                   " <<endl;
}